#!/bin/bash

for X in 1 2 3 A B C
do
      echo item: $X
done
