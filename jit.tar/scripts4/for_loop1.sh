#!/bin/bash

for (( i=1; i >0; i++ ))
do
	echo $i
done
