X=1
Y=2
x="This is Jitendra"
Z=`expr $X + $Y `
echo $Z
echo $X $x
